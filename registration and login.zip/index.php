<?php include('header.php'); ?>
<div class="container">
		<div class="row">
			<div class="col-md-4 col-md-offset-4"><br><br><br><br>
			 <form id="cuslogin">
			  <div class="form-group">
				<label for="uname">User Name:</label>
				<input type="uname" class="form-control" name="uname">
			  </div>
			  <div class="form-group">
				<label for="pass">Password:</label>
				<input type="password" class="form-control" name="pass">
			  </div>
			  
			<input type="submit" class="btn btn-primary" name="save" value="Login"/>
			</form>
			</div>
		</div>
</div>

<?php include('footer.php'); ?>