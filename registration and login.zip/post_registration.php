<?php
	require_once('cls_dbconfig.php');
	function __autoload($classname){
	  require_once("$classname.class.php");
	}
	
	$db = new cls_dbconfig();
	$cls_registration = new cls_registration();
	
	
	$fname = "$_POST[fname]";
	$lname = "$_POST[lname]";
	$uname = "$_POST[uname]";
	$email = "$_POST[email]";
	$fatname = "$_POST[fatname]";
	$mname = "$_POST[mname]";
	$pic = $_FILES['file']['tmp_name'];
	$class_no = "$_POST[class_no]";
	$roll = "$_POST[roll]";	
	$password = md5($_REQUEST['password']);
	
	
	echo $cls_registration->registration($fname,$lname,$uname,$email,$fatname,$mname,$pic,$class_no,$roll,$password);
	
	
	
?>