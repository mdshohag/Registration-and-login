<?php include('header.php'); ?>
<div class="container">
		<div class="row">
			<div class="col-md-10 col-md-offset-1"><br><br><br><br>
			 <form class="form-horizontal" method="post" id="registration" enctype="multipart/form-data">
			  <div class="form-group">
				<label for="fname" class="col-sm-2 control-label">First Name:</label>
				<div class="col-sm-10">
				<input type="text" class="form-control" name="fname">
			  </div>
			  </div>
			   <div class="form-group">
				<label for="lname" class="col-sm-2 control-label">Last Name:</label>
				<div class="col-sm-10">
				<input type="text" class="form-control" name="lname">
			  </div>
			  </div>
			   <div class="form-group">
				<label for="uname" class="col-sm-2 control-label">User name:</label>
				<div class="col-sm-10">
				<input type="text" class="form-control" name="uname">
			  </div>
			  </div>
			  <div class="form-group">
				<label for="email" class="col-sm-2 control-label">Email address:</label>
				<div class="col-sm-10">
				<input type="email" class="form-control" name="email">
			  </div>
			  </div>
			  <div class="form-group">
				<label for="faname" class="col-sm-2 control-label">father Name:</label>
				<div class="col-sm-10">
				<input type="text" class="form-control" name="fatname">
			  </div>
			  </div>
			   <div class="form-group">
				<label for="" class="col-sm-2 control-label">Mother Name:</label>
				<div class="col-sm-10">
				<input type="text" class="form-control" name="mname">
			  </div>
			  </div>
			   <div class="form-group">
				<label for="" class="col-sm-2 control-label">Photo Upload:</label>
				<div class="col-sm-10">
				<input type="file" name="file" >
			  </div>
			  </div>
			   <div class="form-group">
				<label for="" class="col-sm-2 control-label">Class:</label>
				<div class="col-sm-10">
				<input type="text" class="form-control" name="class_no">
			  </div>
			  </div>
			   <div class="form-group">
				<label for="" class="col-sm-2 control-label">Roll no:</label>
				<div class="col-sm-10">
				<input type="text" class="form-control" name="roll">
			  </div>
			  </div>
			  <div class="form-group">
				<label for="pwd" class="col-sm-2 control-label">Password:</label>
				<div class="col-sm-10">
				<input type="password" class="form-control" name="password" >
			  </div>
			  </div> 
			  <div class="form-group">
				<label for="pwd" class="col-sm-2 control-label">Confirm Password:</label>
				<div class="col-sm-10">
				<input type="password" class="form-control" name="repassword" >
			  </div>
			  </div>
			<div class="col-sm-offset-2 col-sm-10">
			  <button type="submit" class="btn btn-success">Sign in</button>
			</div>
			</form>
			</div>
		</div>
</div>

<?php include('footer.php'); ?>