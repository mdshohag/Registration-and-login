<?php
	require_once('cls_dbconfig.php');
	function __autoload($classname){
	  require_once("$classname.class.php");
	}
	$cls_registration = new cls_registration();
	$cls_customer_login = new cls_customer_login();
	
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
    <link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="alert/alertify.min.css">
   <link rel="stylesheet" href="alert/default.min.css">
	</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
			<nav class="navbar navbar-default navbar-fixed-top">
			  <div class="container">
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav">
						<li ><a href="registration.php">Registration</a></li>
						<li><a href="index.php">Login</a></li>
					</ul>
				</div>
			  </div>
			</nav>
			</div>
		</div>
</div>