
  <!-- <script type="text/javascript" src="js/bootstrap.min.js"></script>-->
  <script type="text/javascript" src="js/jquery.js"></script>
  <script src="alert/alertify.min.js"></script>
  <script type="text/javascript">
		$(function(){
			
			$("#registration").submit(function(e){
				e.preventDefault();
				
				var fname = $('[name="fname"]').val();
				var lname = $('[name="lname"]').val();
				var  uname = $('[name="uname"]').val();
				var email = $('[name="email"]').val();
				var fatname = $('[name="fatname"]').val();
				var mname = $('[name="mname"]').val();
				var file = $('[name="file"]').val();
				var class_no = $('[name="class_no"]').val();
				var password = $('[name="password"]').val();
				var repassword = $('[name="repassword"]').val();
				
				
				if(fname == ""){
						alertify.error('Please Enter  Frist name');
						return false;
					}
				if(lname == ""){
						alertify.error('Please Enter  Last name');
						return false;
					}
				if(uname == ""){
						alertify.error('Please Enter  user name');
						return false;
					}
				if(email == ""){
						alertify.error('Please Enter  email');
						return false;
					}
				if(fatname == ""){
						alertify.error('Please Enter  Father name');
						return false;
					}
				if(mname == ""){
						alertify.error('Please Enter  mother name');
						return false;
					}
				if(file == ""){
						alertify.error('Please upload Photo ');
						return false;
					}
				if(class_no == ""){
						alertify.error('Please Enter class no');
						return false;
					}
				if(password == ""){
						alertify.error('Please Enter password');
						return false;
					}
				if(repassword == ""){
						alertify.error('Please Enter repassword');
						return false;
					}
				if(password != repassword) {
						alertify.error("Password and Retype password do not match"); 
						return false;
					}
				
				$.ajax({
					type:"post",
					url:"post_registration.php",
					data:new FormData(this),
					contentType: false,
					cache:false,
					processData:false,
					success:function(res){
						
						if(res == 1){
							alertify.success('Success');
							
							location.href='index.php';
							
						}else if(res == 2){
							alertify.error('Exist Email');
						}else if(res == 3){
							alertify.error('Exist User Name');
						}else{
							alertify.success('Success');
						}
					
					  
					},error:function(){
						alertify.error('Error on Ajax');
					}     
				})
			});
		})
	</script>
  
	<script>
	$(function(){
		$("#cuslogin").submit(function(e){
				e.preventDefault();
				
				$.ajax({
					type:"post",
					url:"cus_login.php",
					data:new FormData(this),
					contentType: false,
					cache:false,
					processData:false,
					success:function(res){
						
					//alert(res);
					//return false;
					
					if(res == 'no'){
						alertify.error('Username or Password does not match !!');
						return false;
					}
					location.href='dashboard.php';
				}
			})
			
		});
	});
	</script>
</body>
</html>