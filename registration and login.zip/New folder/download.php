<?php
	require_once('functions/cls_dbconfig.php');
	function __autoload($classname){
		require_once("functions/$classname.class.php");
	}
    $cls_institute_info = new cls_institute_info();
	$cls_notice = new cls_notice();
	$cls_news = new cls_news();
	$cls_download = new cls_download();
	$cls_utility = new cls_utility();
	$cls_page_content = new cls_page_content();
	$cls_principal_mess = new cls_principal_mess();
	$cls_stuProfile = new cls_stuProfile();
	$cls_tcrProfile = new cls_tcrProfile();
	$cls_class = new cls_class();
	$cls_department = new cls_department();
	$cls_gallery_album = new cls_gallery_album();
	$cls_add_gallery_img = new cls_add_gallery_img();
	$cls_add_slider_img = new cls_add_slider_img();
	$cls_latestnews = new cls_latestnews();
	$cls_importantlink = new cls_importantlink();
	$cls_result_upload = new cls_result_upload();
	
	$inst_info_query = $cls_institute_info->view_info();
	$inst_info = $inst_info_query->fetch_assoc();

       //principal mess query//
        $prin_mess_query = $cls_principal_mess->principal_mess();
	$mess_info = $prin_mess_query->fetch_assoc();
	
	//president mess query//
	$president_mess=$cls_principal_mess->president_mess();
	$presi_mes=$president_mess->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en-US" prefix="og: http://ogp.me/ns#">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="">

<title> Uttara Academy | ?????? ???????  </title>
<base href="http://uttaraacademy.com/">
<meta name="keywords" content=""/>
<meta name="description" content="Towards the journey of higher education in Bangladesh Rajshahi College is one of the path finders and a distinctive institution."/>
<meta name="robots" content="noodp"/>

<link rel="stylesheet" id="contact-form-7-css"  href="css/style.css" type="text/css" media="all" />
<link rel="stylesheet" id="iau-bootstrap-css"  href="css/bootstrap.min.css" type="text/css" media="" />
<link rel="stylesheet" id="iau-animate-css"  href="css/animate.min.css" type="text/css" media="" />
<link rel="stylesheet" id="iau-lightbox-css"  href="css/lightbox.css" type="text/css" media="" />
<link rel="stylesheet" id="iau-owl-carousel-css"  href="css/owl.carousel.css" type="text/css" media="" />
<link rel="stylesheet" id="iau-style-css"  href="style.css" type="text/css" media="all" />
<link rel="stylesheet" id="iau-custom-style-css"  href="css/custom-style.css" type="text/css" media="" />
<script type="text/javascript" src="js/jquery-1.9.0.min.js"></script>
 
<script type="text/javascript" src="js/jquery-migrate.min.js"></script>
<link rel="#" href="wp-json/" />

</head>

<body class="home page page-id-4 page-template page-template-page-home page-template-page-home-php">
<div id="page" class="site">

 
	<header id="masthead" class="site-header" role="banner">
		
			<div class="container">
				<div class="row">
					<div class="col-sm-1">
					 
						 <img class="logo" src="images/logo.png" alt="logo"> 
					</div>
					<div class="col-sm-8" style="margin-left:-17px !important;">
					 
						<p style="margin:10px 0px 0px 0px;font-size:30px;">?????? ??????? </p>
						 <p style="float:left;margin:0px 0px 0px 10px;font-size:24px;">Uttara Academy</p>
						 
					</div>
					<div class="col-sm-3">
						          
						<p><br>EIIN - 61041<br>Institute Code - 61041</p>
					</div>
				</div>
			</div>
			
		<section class="header"><!--Start Header Section-->
			<div class="container-fluid menubar">
				<nav class="navbar navbar-header">

					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
					</div>

					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="container">
						<div class="collapse navbar-collapse mainmenu" id="bs-example-navbar-collapse-1">
							<ul class="nav nav-justified">
								<li class="active"><a href="index.php">Home</a></li>
								<li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" href="/notice/">About<span class="caret"></span></a>
									<ul class="dropdown-menu" role="menu">
										<li><a href="overview.php">Overview</a></li>
										<li><a href="history.php"> History </a></li>
										<li><a href="page_content/type/landdet">Land Details </a></li>
										<li><a href="page_content/type/preprin">present principal</a></li>
										<li><a href="page_content/type/prinli">principal list </a></li>
										<li><a href="page_content/type/vprinin">Present vice principal</a></li>
										<li><a href="page_content/type/vprinli">vice principal list </a></li>
										 
									</ul>
								</li>
								<li class="dropdown"><a  class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" href="/notice/">Admission<span class="caret"></span></a> 
								
								<ul class="dropdown-menu" role="menu">
										 
										<li><a href="page_content/type/adate">admission date</a></li>
								</ul>
								
								
								</li>
								<li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" href="/notice/">Academic<span class="caret"></span></a>
									<ul class="dropdown-menu" role="menu">
										<li><a href="page_content/type/rulregu">Rules & Regulation</a></li>
										<li><a href="page_content/type/accal">Academic Calender</a></li>
										<li><a href="page_content/type/hollist"> Holiday List </a></li>
										<li><a href="page_content/type/syllabus">Syllabus</a></li>
										<li><a href="page_content/type/strules"> Student List</a></li>
<li><a href="student_search">Student Search</a></li>
										<li><a href="page_content/type/clsrou"> Class Routines</a></li>
										<li><a href="page_content/type/compsub"> Compulsory Subject</a></li>
									</ul>
								</li>
								<li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" href="/notice/">Offcial<span class="caret"></span></a>
									<ul class="dropdown-menu" role="menu">
										 
										<li><a href="page_content/type/teali"> Teacher List </a></li>
										<li><a href="page_content/type/stuli"> Stuff List </a></li>
									</ul>
								</li>
								<li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" href="/notice/">Library<span class="caret"></span></a>
									<ul class="dropdown-menu" role="menu">
										<li><a href="page_content/type/libs"> Science </a></li>
										<li><a href="page_content/type/liba"> Arts </a></li>
										<li><a href="page_content/type/libc"> Commerce </a></li>
									</ul>
								</li>
								<li><a href="reslult.php">Results</a></li>
								<li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" href="">Department<span class="caret"></span></a>
									<ul class="dropdown-menu" role="menu">
										<li><a href="page_content/type/sdepart"> Science  </a></li>
										<li><a href="page_content/type/adepart"> Arts   </a></li>
										<li><a href="page_content/type/cdepart"> Commerce  </a></li>
									</ul>
								
								</li>
								<li><a href="gallery.php">Photo Gallery</a></li>
								<li><a href="download.php">Downloadsss</a></li>
								<li><a href="student-login.php">Student </a></li>
							</ul>
						</div><!-- /.navbar-collapse -->
					</div>

				</nav>
			</div><!-- /.container-fluid -->


			<div class="container slider-section">
				<div class="row">
					<div class="col-md-8">
						<div class="slider">

							<!-- To move inline styles to css file/block, please specify a class name for each element. -->
							<div id="sliderb_container" style="position: relative; top: 0px; left: 0px; width: 660px;
                                height: 265px; overflow: hidden;">

								<!-- Loading Screen -->
								<div data-u="loading" style="position: absolute; top: 0px; left: 0px;">
									<div style="filter: alpha(opacity=70); opacity:0.7; position: absolute; display: block;
                                        background-color: #000; top: 0px; left: 0px;width: 100%;height:100%;">
									</div>
									<div style="position: absolute; display: block; background: url(images/loading.gif) no-repeat center center;
                                        top: 0px; left: 0px;width: 100%;height:100%;">
									</div>
								</div>

								<!-- Slides Container -->
								<div data-u="slides" style="cursor: move; position: absolute; left: 0px; top: 0px; width: 660px; height: 265px;overflow: hidden;">

								<?php
						 
									  $all_slide = $cls_add_slider_img->view_all();
									  while ($row = $all_slide->fetch_assoc()){
						
										echo '<div><img src="images/photo_slider_img/' . $row['file_name'] . '" alt="'.$row['file_name'] .'"  width="1024" height="400"/>
										
										<div data-u="thumb">' .$row['img_title'].'</div>
										
										</div>' ;
                                   
									} 
									 
								?>
									 
									
								</div>

								<!--#region Thumbnail Navigator Skin Begin -->

								<!-- thumbnail navigator container -->

								<div data-u="thumbnavigator" style="position: absolute; bottom: 0px; left: 0px; height:45px; width:660px;">
									<div style="filter: alpha(opacity=40); opacity:0.4; position: absolute; display: block;
                                        background-color: #000000; top: 0px; left: 0px; width: 100%; height: 100%;">
									</div>
									<!-- Thumbnail Item Skin Begin -->
									<div data-u="slides">
										<div data-u="prototype" style="POSITION: absolute; WIDTH: 660px; HEIGHT: 45px; TOP: 0; LEFT: 0;">
											<div data-u="thumbnailtemplate" style="font-family: kalpurush, 'kalpurush'; font-weight: normal; POSITION: absolute; WIDTH: 100%; HEIGHT: 100%; TOP: 0; LEFT: 0; color:#fff; line-height: 45px; font-size:20px; padding-left:10px;"></div>
										</div>
									</div>
									<!-- Thumbnail Item Skin End -->
								</div>
								<!--#endregion ThumbnailNavigator Skin End -->


								<!-- bullet navigator container -->
								<div data-u="navigator" class="jssorb01" style="bottom: 16px; right: 10px;">
									<!-- bullet navigator item prototype -->
									<div data-u="prototype"></div>
								</div>
								<!--#endregion Bullet Navigator Skin End -->

								<!-- Arrow Left -->
                                <span data-u="arrowleft" class="jssora05l" style="top: 123px; left: 8px;">
                                </span>
								<!-- Arrow Right -->
                                <span data-u="arrowright" class="jssora05r" style="top: 123px; right: 8px;">
                                </span>
								<!-- Trigger -->
							</div>

						</div>
					</div>
					<div class="col-md-4">
						<div class="notice">
							<h4 class="text-center title">????? ?????</h4>
							<div class="block-content">
								<div class="marquee ver" data-direction='up' data-duration=5000 style="height: 200px;">
									<ul>
									<?php $nb = $cls_notice->view_all(); while($row_nb = $nb->fetch_assoc()){ ?>
										 
										<li><a href="notice_details.php?id=<?php echo $row_nb['id'];?>"><?php echo $row_nb['notice_title']; ?></a></li>
										
									<?php } ?>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

		</section><!--End Header Section-->
	</header>
	
	<div id="content" class="site-content">
	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

			
				
<article id="post-4" class="post-4 page type-page status-publish hentry">
	<section class="main-content"><!-- Start Main Content Section-->

		<div class="container">
			<div class="row">
				<div class="latest">
					<h4 class="col-sm-2 text-center kalpurush">??????? ?????</h4>
					<div class="col-sm-10 news">
						<div class="marquee">
							<?php
							 $lat_news_q = $cls_latestnews->view_all_home();
							while($lat_news_r = $lat_news_q->fetch_assoc()){ 
							?>
                            <a href="latest_news_details.php?id=<?php echo "$lat_news_r[id]"; ?>"><?php echo "$lat_news_r[latest_news_title]"; ?></a> &nbsp;&nbsp;
							<?php echo "| &nbsp;&nbsp;"; } ?> 
						</div>
					</div>
				</div>
			</div>

	 
			<div class="row">
				<div class="col-md-8">
					<div class="content-block history">
						<h4 class="text-center">Download</h4>
						<div class="block-contents animate-from-right animated">
							<div class="content_element">
							 <ul class="download_list" style="list-style:none;">
								<?php
								
								$dnl_query = $cls_download->view_all();
								while($dnl_row = $dnl_query->fetch_assoc()){
								?>
								<li><a href="<?php echo "http://pmahschool.edu.bd/files/downloads/$dnl_row[filename]";?>" target="_blank"><?php echo "$dnl_row[download_title]";?></a></li>
								<?php }?>
							</ul>
							</div>
						</div>
					</div>
				</div>
				 
<?php 
$importantlink=$cls_importantlink->view_all_home();


?>
 <div class="col-md-4">
					<div class="content-block">
						<h4 class="text-center">Director </h4>
						<div class="block-content animate-from-bottom animated">
							<div class="messages">
								<div class="col-md-5">
									<img alt="vc-iau" class="img-responsive" src="images/president_img.jpg" width="100" height="60" >
									 
								 
								</div>
								 
									 
								<p style="text-align:justify;"><span class="awesome">?</span>&nbsp;&nbsp;<?php echo $pmess=substr($presi_mes['president_mess'],0,640);?>.... </p><br>
								 <a  style="color:#709500;" href="president_messfull.php" class="welcome_read_more">Read More</a>
								 
								 
								 
							</div>
						</div>
					</div>
				</div>


<div class="clearfix"></div>
				<div class="col-md-4">
					<div class="content-block notice top-15">
						<h4 class="text-center title">???????</h4>
						<div class="block-content slide-from-left animated">
							<ul>
								 <?php
							
									$dnl_query = $cls_download->view_all();
									while($dnl_row = $dnl_query->fetch_assoc()){
									?>
									<li><a href="<?php echo "files/downloads/$dnl_row[filename]";?>"><?php echo "$dnl_row[download_title]";?></a></li>
									<?php }?>
							</ul>
						</div>
					</div>
				</div>
				 
				 <div class="col-md-4">
					<div class="content-block notice top-15">
						<h4 class="text-center title"> ???????????? ????</h4>
						<div class="block-content side-nav animate-from-left animated">
						
							<ul>
							<?php while($view_link=$importantlink->fetch_assoc()){
								
								
								?>
								<li><a href="<?php echo "$view_link[link_url]";?>" target="_blank"><?php echo "$view_link[link_title]";?></a></li>
							<?php }?>
								 
							</ul>
							
							</div>
						</div>
					</div>
				 
				 
				 
				 <div class="col-md-4">
					<div class="content-block notice top-15">
						<h4 class="text-center title">Contact Us</h4>
						<div class="block-content side-nav animate-from-left animated">
							 
							<p class="text-center">
								?????? :????? ???????,??? ?? ??,??????-?, ??????, ???? 
								
								<br>
								<?php echo $inst_info['address'];?><br>
								???????: ???????????  <?php echo $inst_info['phone'];?><br>
								??????? :     <?php echo $inst_info['fax'];?><br>
								?????? : ??????????? <?php echo $inst_info['mobile'];?><br>
								??????   : zillurnathpur@gmail.com<?php echo $inst_info['email'];?>
							</p><br>
							
							
							
						</div>
						
					</div>
					
				</div>
<?php 

$gallery_img=$cls_add_gallery_img->view_all_img();
//$row=$gallery_img->fetch_assoc();

?>

				 <div class="col-sm-12 bottom-block">
				
				
					<div class="col-sm-3 bottom-block">
						 
							<img src="images/bangladesh.gif" alt="iau013" width="300" height="200">
						 
					</div>
					<div class="col-sm-9 bottom-block">
					
						<div class="image-carousel">
						 
						  <div id="owl-demo" class="owl-carousel">
									  
								<?php 
								while($row=$gallery_img->fetch_assoc()){
								?>
									<div class="item"><a data-lightbox="iau-home" href="<?php echo "images/photo_gallery_img/$row[file_name]";?>"><img src="<?php echo "images/photo_gallery_img/$row[file_name]";?>" alt="<?php echo "images/photo_gallery_img/$row[image_title]";?>"   height="200"></a></div>
								<?php
								
								}
								
								?>
							
							<!--
							<div class="item"><a data-lightbox="iau-home" href="images/gallery014.jpg"><img src="images/gallery014.jpg" alt="iau014"></a></div>
							<div class="item"><a data-lightbox="iau-home" href="images/gallery015.jpg"><img src="images/gallery015.jpg" alt="iau015"></a></div>
							<div class="item"><a data-lightbox="iau-home" href="images/gallery005.jpg"><img src="images/gallery005.jpg" alt="iau005"></a></div>
							<div class="item"><a data-lightbox="iau-home" href="images/gallery007.jpg"><img src="images/gallery007.jpg" alt="iau007"></a></div>
							<div class="item"><a data-lightbox="iau-home" href="images/gallery012.jpg"><img src="images/gallery012.jpg" alt="iau012"></a></div>
							<div class="item"><a data-lightbox="iau-home" href="images/gallery009.jpg"><img src="images/gallery009.jpg" alt="iau009"></a></div>
							<div class="item"><a data-lightbox="iau-home" href="images/gallery006.jpg"><img src="images/gallery006.jpg" alt="iau006"></a></div>-->
						</div>

					</div>
				
				</div>
				 	
				</div>

				<!-- modal -->
				<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					<div class="modal-dialog">
						<div class="modal-content">
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&#10006;</button>
							</div>
							<div class="modal-body">
								<img alt="gallery-iau" id="mimg" src="">
							</div>
						</div><!-- /.modal-content -->
					</div><!-- /.modal-dialog -->
				</div><!-- /.modal -->


			</div>
		</div>

	</section><!-- End Main Content Section-->
</article><!-- #post-## -->

			
		</main><!-- #main -->
	</div><!-- #primary -->


	</div><!-- #content -->









	<footer id="colophon" class="site-footer" role="contentinfo">
		<section class="footer"><!-- Start Footer Section-->

			<div class="footer-bottom text-center small">
				<h4>&copy; All rights reserved. <a href="http://mdmasumpramanik.info/" style="color:white;">Developed by Masum Pramanik</a></h4>
			</div>

		</section><!-- Start Footer Section-->


		</div><!--End Main Container-->

		</div><!--End Main Wrapper-->


	</footer><!-- #colophon -->
</div><!-- #page -->

	<div style="display:none">
	</div>
<script type="text/javascript" src="js/jquery.form.min.js"/></script>
<script type='text/javascript'>
/* <![CDATA[ */
var _wpcf7 = {"loaderUrl":"http:\/\/localhost\/iau_wordpress\/wp-content\/plugins\/contact-form-7\/images\/ajax-loader.gif","recaptchaEmpty":"Please verify that you are not a robot.","sending":"Sending ...","cached":"1"};
/* ]]> */
</script>
<script type="text/javascript" src="js/scripts.js"></script>
<script type="text/javascript" src="js/gprofiles.js"></script>
<script type="text/javascript">
/* <![CDATA[ */
var WPGroHo = {"my_hash":""};
/* ]]> */
</script>
<script type="text/javascript" src="js/wpgroho.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jssor.js"></script>
<script type="text/javascript" src="js/jssor.slider.js"></script>
<script type="text/javascript" src="js/slider.js"></script>
<script type="text/javascript" src="js/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/jquery.waypoints.min.js"></script>
<script type="text/javascript" src="js/jquery.marquee.min.js"></script>
<script type="text/javascript" src="js/lightbox.js"></script>
<script type="text/javascript" src="js/custom.js"></script>
<script type="text/javascript" src="js/devicepx-jetpack.js"></script>
<script type="text/javascript" src="js/wp-embed.min.js"></script>
<!-- Clicky -->
<script src="//static.getclicky.com/js" type="text/javascript"></script>
<script type="text/javascript">try{ clicky.init(100899632); }catch(e){}</script>
<noscript><p><img alt="Clicky" width="1" height="1" src="//in.getclicky.com/100899632ns.gif" /></p></noscript>
</body>
</html>