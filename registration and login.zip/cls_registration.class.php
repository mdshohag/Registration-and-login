<?php
	class cls_registration{
		public function con(){
			$connect = new cls_dbconfig();
			return $connect->connection();
		}
		
		public function registration($fname,$lname,$uname,$email,$fatname,$mname,$pic,$class_no,$roll,$password){
			
			
			$yes = 2;
			
			$res = $this->con()->query("SELECT email From tbl_reg where email='$email'");
			$count = $res->num_rows;
			
			if($count != 0){
				return $yes;
				return false;
			}
			
			$yes_m = 3;
			
			$res = $this->con()->query("SELECT user_name From tbl_reg where user_name='$uname'");
			$count = $res->num_rows;
			
			if($count != 0){
				return $yes_m;
				return false;
			}
			
			if($pic != ""){
			$r = rand('1111','9999');
			$picc = "$r.jpg";
			
			$destination = "photo/$picc";
			
			move_uploaded_file($pic,$destination);			
		}
			
			$result=$this->con()->query("INSERT INTO tbl_reg (fname,lname,user_name,email,fathname,mother,image,class,roll,password) VALUES ('$fname','$lname','$uname','$email','$fatname','$mname','$picc','$class_no','$roll','$password')");
			return $result;
			
			
		}
		
	}

?>