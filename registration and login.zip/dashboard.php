<?php
 session_start();
	if(!isset($_SESSION['customer_id'])){
		
		echo "<script>location.href='index.php';</script>";
	}
	require_once('cls_dbconfig.php');
	function __autoload($classname){
	  require_once("$classname.class.php");
	}
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
    <link rel="stylesheet" href="css/bootstrap.min.css">
	</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
			<nav class="navbar navbar-default navbar-fixed-top">
			  <div class="container">
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav">
						<li><a ><?php echo $_SESSION['customer_fname'];?></a></li>
						<li><a href="#" id="signouts">Log Out</a></li>
					</ul>
				</div>
			  </div>
			</nav>
			</div>
		</div>
</div>
  <script type="text/javascript" src="js/jquery.js"></script>
  
	<script>
	$(function(){
		$("#signouts").click(function(e){
			e.preventDefault();
			//alert('ok');
			$.ajax({
				type:'post',
				url:'signout.php',
				success:function(res){
					//alert(res);
					if(res == '1'){
						location.href='index.php';
					}else{
						alertify.error('Error on Logout');
					}
				}
			})
		});
	})
	</script>
  </body>
  </html>
